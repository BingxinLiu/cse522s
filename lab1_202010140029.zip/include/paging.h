#ifndef __PAGING_H
#define __PAGING_H

/* Seen by kernel and user */
#define PAGING_MODULE_NAME "paging"
#define DEV_NAME "/dev/" PAGING_MODULE_NAME

#endif
